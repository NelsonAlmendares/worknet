<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class District
 * 
 * @property int $iddistrict
 * @property string $distname
 * @property string $dist_e
 * @property string $dist_idmh
 * 
 * @property Collection|Municip[] $municips
 *
 * @package App\Models
 */
class District extends Model
{
	protected $table = 'district';
	protected $primaryKey = 'iddistrict';
	public $timestamps = false;

	protected $fillable = [
		'distname',
		'dist_e',
		'dist_idmh'
	];

	public function municips()
	{
		return $this->hasMany(Municip::class, 'munip_iddistrict');
	}
}
