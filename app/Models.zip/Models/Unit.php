<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Unit
 * 
 * @property int $idunit
 * @property string $unitname
 * @property string $unitintercode
 * @property string $unitdesc
 * @property string $unitobj
 * @property string $unittel
 * @property int $unitmanager_idemp
 * @property string $unitlocation
 * @property Carbon $unitborndate
 * @property string $unitemail
 * @property string $unit_e
 * 
 * @property Employee $employee
 * @property Position $position
 *
 * @package App\Models
 */
class Unit extends Model
{
	protected $table = 'unit';
	protected $primaryKey = 'idunit';
	public $timestamps = false;

	protected $casts = [
		'unitmanager_idemp' => 'int',
		'unitborndate' => 'datetime'
	];

	protected $fillable = [
		'unitname',
		'unitintercode',
		'unitdesc',
		'unitobj',
		'unittel',
		'unitmanager_idemp',
		'unitlocation',
		'unitborndate',
		'unitemail',
		'unit_e'
	];

	public function employee()
	{
		return $this->belongsTo(Employee::class, 'unitmanager_idemp');
	}

	public function position()
	{
		return $this->hasOne(Position::class, 'posit_idunit');
	}
}
