<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Rol
 * 
 * @property int $idrol
 * @property string $rolname
 * @property string $roldesc
 * @property int $rol_modul
 * @property int $rol_rept
 * @property int $rol_menu
 * @property string $rol_e
 * 
 * @property Modul $modul
 * @property Report $report
 * @property Menu $menu
 * @property Collection|User[] $users
 *
 * @package App\Models
 */
class Rol extends Model
{
	protected $table = 'rol';
	protected $primaryKey = 'idrol';
	public $timestamps = false;

	protected $casts = [
		'rol_modul' => 'int',
		'rol_rept' => 'int',
		'rol_menu' => 'int'
	];

	protected $fillable = [
		'rolname',
		'roldesc',
		'rol_modul',
		'rol_rept',
		'rol_menu',
		'rol_e'
	];

	public function modul()
	{
		return $this->belongsTo(Modul::class, 'rol_modul');
	}

	public function report()
	{
		return $this->belongsTo(Report::class, 'rol_rept');
	}

	public function menu()
	{
		return $this->belongsTo(Menu::class, 'rol_menu');
	}

	public function users()
	{
		return $this->belongsToMany(User::class, 'user_rol', 'ur_idrol', 'ur_iduser')
					->withPivot('id_ur', 'ur_e');
	}
}
