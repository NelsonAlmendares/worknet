<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Position
 * 
 * @property int $idposition
 * @property string $positname
 * @property string $positdesc
 * @property string $positstate
 * @property string $positrequest
 * @property int $posit_idunit
 * @property int $posit_idtypeposit
 * 
 * @property TypePosition $type_position
 * @property Unit $unit
 * @property Employee $employee
 *
 * @package App\Models
 */
class Position extends Model
{
	protected $table = 'position';
	protected $primaryKey = 'idposition';
	public $timestamps = false;

	protected $casts = [
		'posit_idunit' => 'int',
		'posit_idtypeposit' => 'int'
	];

	protected $fillable = [
		'positname',
		'positdesc',
		'positstate',
		'positrequest',
		'posit_idunit',
		'posit_idtypeposit'
	];

	public function type_position()
	{
		return $this->belongsTo(TypePosition::class, 'posit_idtypeposit');
	}

	public function unit()
	{
		return $this->belongsTo(Unit::class, 'posit_idunit');
	}

	public function employee()
	{
		return $this->hasOne(Employee::class, 'emp_idprofession');
	}
}
